package com.example.llama

import android.annotation.SuppressLint
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.net.Uri
import android.os.Bundle
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.arm.aichat.AiChat
import com.arm.aichat.InferenceEngine
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch
import kotlinx.coroutines.flow.collect
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream

/** Native Caption Creator: local assets, on-device GGUF inference. */
class MainActivity : AppCompatActivity() {
    private lateinit var browser: WebView
    private var pageReady = false
    private var engine: InferenceEngine? = null
    @Volatile private var modelReady = false
    private var modelName = ""
    @Volatile private var generating = false
    private var generationJob: Job? = null

    private val modelPicker = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) importModel(uri)
    }

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = android.graphics.Color.rgb(21, 18, 31)
        window.navigationBarColor = android.graphics.Color.rgb(21, 18, 31)
        browser = WebView(this).apply {
            setBackgroundColor(android.graphics.Color.rgb(21, 18, 31))
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            settings.allowFileAccess = true
            settings.allowContentAccess = false
            settings.javaScriptCanOpenWindowsAutomatically = false
            settings.setSupportMultipleWindows(false)
            webChromeClient = WebChromeClient()
            webViewClient = object : WebViewClient() {
                override fun onPageFinished(view: WebView?, url: String?) {
                    pageReady = true
                    updateStatus(if (modelReady) "Model ready: $modelName" else "Select a GGUF model to begin", modelReady)
                }
                override fun shouldOverrideUrlLoading(view: WebView?, request: android.webkit.WebResourceRequest?): Boolean = true
            }
            addJavascriptInterface(NativeBridge(), "CaptionAndroid")
            loadUrl("file:///android_asset/index.html")
        }
        setContentView(browser)

        lifecycleScope.launch(Dispatchers.Default) {
            try {
                engine = AiChat.getInferenceEngine(applicationContext)
                val saved = File(filesDir, "models/selected.gguf")
                if (saved.isFile && saved.length() > 0) {
                    updateStatus("Loading previous GGUF model…", false)
                    engine!!.loadModel(saved.absolutePath)
                    modelName = getPreferences(MODE_PRIVATE).getString("modelName", saved.name) ?: saved.name
                    modelReady = true
                    updateStatus("Model ready: $modelName", true)
                } else updateStatus("Select a GGUF model to begin", false)
            } catch (e: Exception) {
                modelReady = false
                updateStatus("AI initialization error: ${e.message ?: e.javaClass.simpleName}", false)
            }
        }
    }

    inner class NativeBridge {
        @JavascriptInterface fun chooseModel() {
            runOnUiThread {
                if (generating) updateStatus("Finish this batch before switching models", true)
                else modelPicker.launch(arrayOf("application/octet-stream", "application/x-gguf", "*/*"))
            }
        }

        @JavascriptInterface fun generate(prompt: String, quantity: Int) {
            runOnUiThread { startGeneration(prompt, quantity.coerceIn(1, 10)) }
        }

        @JavascriptInterface fun copyText(value: String) {
            val clipboard = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            runOnUiThread { clipboard.setPrimaryClip(ClipData.newPlainText("Caption", value)) }
        }
    }

    private fun importModel(uri: Uri) {
        if (generating) return
        lifecycleScope.launch(Dispatchers.IO) {
            val hadModel = modelReady
            val target = File(filesDir, "models/selected.gguf")
            val temporary = File(target.parentFile, "selected.gguf.partial")
            try {
                modelReady = false
                updateStatus("Copying GGUF to private app storage…", false)
                target.parentFile?.mkdirs()
                contentResolver.openInputStream(uri)?.use { input ->
                    FileOutputStream(temporary).use { output ->
                        val buffer = ByteArray(1024 * 1024)
                        var n: Int
                        var bytes = 0L
                        var lastNotice = 0L
                        while (input.read(buffer).also { n = it } != -1) {
                            output.write(buffer, 0, n)
                            bytes += n
                            if (bytes - lastNotice >= 128L * 1024 * 1024) {
                                lastNotice = bytes
                                updateStatus("Copying GGUF… ${bytes / 1048576} MB", false)
                            }
                        }
                    }
                } ?: throw IllegalStateException("Unable to read the selected model")
                if (temporary.length() == 0L) throw IllegalStateException("The model file is empty")
                val runningEngine = engine ?: AiChat.getInferenceEngine(applicationContext).also { engine = it }
                if (hadModel) runningEngine.cleanUp()
                if (target.exists() && !target.delete()) throw IllegalStateException("Unable to replace previous model")
                if (!temporary.renameTo(target)) throw IllegalStateException("Unable to save model")
                updateStatus("Loading GGUF model into memory…", false)
                runningEngine.loadModel(target.absolutePath)
                modelName = contentResolver.query(uri, arrayOf(android.provider.OpenableColumns.DISPLAY_NAME), null, null, null)?.use {
                    if (it.moveToFirst()) it.getString(0) else null
                } ?: "selected.gguf"
                getPreferences(MODE_PRIVATE).edit().putString("modelName", modelName).apply()
                modelReady = true
                updateStatus("Model ready: $modelName", true)
            } catch (e: Exception) {
                modelReady = false
                updateStatus("Model loading failed: ${e.message ?: e.javaClass.simpleName}", false)
            } finally { temporary.delete() }
        }
    }

    private fun startGeneration(prompt: String, count: Int) {
        if (generating) return
        if (!modelReady || engine == null) {
            updateStatus("Select and load a GGUF model first", false)
            return
        }
        if (prompt.isBlank()) {
            updateStatus("Please enter a caption idea", true)
            return
        }
        generating = true
        emit("onStart", "")
        generationJob = lifecycleScope.launch(Dispatchers.Default) {
            var finished = 0
            try {
                for (index in 1..count) {
                    updateStatus("Generating caption $index of $count…", true)
                    val output = StringBuilder()
                    val singlePrompt = "$prompt\n\nCreate variation $index of $count. Return only one caption; avoid repeating earlier variations."
                    engine!!.sendUserPrompt(singlePrompt, predictLength = 280).collect { output.append(it) }
                    val caption = output.toString().trim()
                    if (caption.isBlank()) throw IllegalStateException("The model returned an empty caption")
                    finished++
                    emit("onCaption", caption)
                }
                updateStatus("Finished $finished caption(s)", true)
                emit("onFinished", "Finished $finished caption(s)")
            } catch (_: CancellationException) {
                emit("onFinished", "Generation interrupted when the app closed")
            } catch (e: Exception) {
                val error = "Stopped after $finished caption(s): ${e.message ?: e.javaClass.simpleName}"
                updateStatus(error, true)
                emit("onFinished", error)
            } finally { generating = false }
        }
    }

    private fun updateStatus(message: String, ready: Boolean) {
        emit("onModelStatus", JSONObject().put("message", message).put("ready", ready).toString())
    }

    /** Use quoted JSON strings, never string-interpolate user text into JavaScript code. */
    private fun emit(event: String, payload: String) {
        runOnUiThread {
            if (pageReady) {
                val script = "window.CaptionNative && window.CaptionNative.$event(${JSONObject.quote(payload)})"
                browser.evaluateJavascript(script, null)
            }
        }
    }

    override fun onDestroy() {
        generationJob?.cancel()
        try { engine?.destroy() } catch (_: Exception) { }
        browser.removeJavascriptInterface("CaptionAndroid")
        browser.destroy()
        super.onDestroy()
    }
}
