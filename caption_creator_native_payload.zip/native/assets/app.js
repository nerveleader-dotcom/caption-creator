const $=id=>document.getElementById(id), baseGoals=['Seeing her breasts','Receiving oral sex','Having vaginal sex','Having anal sex','Giving oral sex'];
const categories={'Persuasion & Influence':['Persuasive','Smooth Talker','Charismatic','Charming','Silver-Tongued','Convincing','Manipulative','Cunning','Scheming'],'Trickery & Deception':['Tricky','Deceptive','Sneaky','Calculating','Prankster','Dishonest','Opportunistic','Secretive'],'Confidence & Control':['Dominant','Assertive','Confident','Cocky','Bold','Controlling','Strategic','Competitive','Intimidating'],'Social & Romantic':['Flirtatious','Seductive','Playful','Romantic','Patient','Observant','Mysterious','Adventurous','Trustworthy'],'Other Personality Traits':['Shy','Naive','Gullible','Trusting','Submissive','Rebellious','Jealous','Possessive','Impulsive']};
const extra=['Impressionable','Suggestible','Easily Persuaded','People Pleaser','Approval-Seeking','Conflict-Avoidant','Overly Trusting','Credulous','Easily Swayed','Dependent','Indecisive','Insecure','Eager to Please','Soft-Hearted','Unassertive','Conformist','Idealistic','Conflict-Sensitive'];
const writing=['Storytelling','Dialogue','First Person','Second Person','Third Person','Confession','Inner Thoughts','Text Messages','Twist Ending','Teasing & Suggestive'];
const load=(key,fallback)=>{try{return JSON.parse(localStorage.getItem(key))??fallback}catch{return fallback}};
let state=load('cc-settings',{}),custom=load('cc-goals',[]),saved=load('cc-saved',[]),generated=[];
const persist=()=>localStorage.setItem('cc-settings',JSON.stringify(state));
function bind(el,key){if(state[key]!==undefined)el.value=state[key];el.addEventListener('input',()=>{state[key]=el.value;persist()})}
function makeSelect(label,key,options){const wrap=document.createElement('label');wrap.textContent=label;const sel=document.createElement('select');sel.dataset.key=key;options.forEach(x=>sel.add(new Option(x,x)));bind(sel,key);wrap.append(sel);return wrap}
function makeChecks(container,key,items){const grid=document.createElement('div');grid.className='checks';items.forEach(name=>{const label=document.createElement('label'),input=document.createElement('input');input.type='checkbox';input.checked=(state[key]||[]).includes(name);input.onchange=()=>{const s=new Set(state[key]||[]);input.checked?s.add(name):s.delete(name);state[key]=[...s];persist()};label.append(input,' '+name);grid.append(label)});container.append(grid)}
for(const gender of ['Female','Male']){const box=document.createElement('details');box.open=gender==='Female';box.innerHTML='<summary>'+gender+' character</summary>';box.append(makeSelect('Relationship','relationship'+gender,gender==='Female'?['Single','Your Girlfriend','Your Wife','Your Ex-Girlfriend','Your Ex-Wife']:['Single','Your Boyfriend','Your Husband','Your Ex-Boyfriend','Your Ex-Husband']));for(const [category,traits] of Object.entries(categories)){const d=document.createElement('details');d.innerHTML='<summary>'+category+'</summary>';makeChecks(d,gender+category,traits);box.append(d)}if(gender==='Female'){const d=document.createElement('details');d.innerHTML='<summary>Influence & Vulnerability</summary>';makeChecks(d,gender+'Influence & Vulnerability',extra);box.append(d)}$('characters').append(box)}
makeChecks($('styles'),'styles',writing);
function renderGoals(){const el=$('goal'),current=state.goal||baseGoals[0];el.replaceChildren();[...baseGoals,...custom].forEach(x=>el.add(new Option(x,x)));el.value=[...baseGoals,...custom].includes(current)?current:baseGoals[0];state.goal=el.value;persist()}
renderGoals();$('goal').onchange=()=>{state.goal=$('goal').value;persist()};$('addGoal').onclick=()=>{const g=$('customGoal').value.trim();if(!g||[...baseGoals,...custom].some(x=>x.toLowerCase()===g.toLowerCase()))return;custom.push(g);localStorage.setItem('cc-goals',JSON.stringify(custom));state.goal=g;renderGoals();$('customGoal').value=''};
$('deleteGoal').onclick=()=>{const g=$('goal').value;if(!custom.includes(g))return;custom=custom.filter(x=>x!==g);localStorage.setItem('cc-goals',JSON.stringify(custom));state.goal=baseGoals[0];renderGoals()};
for(const key of ['idea','length','count','customLength','endpoint','model'])bind($(key),key);
$('count').oninput=()=>{$('countLabel').textContent=$('count').value;state.count=$('count').value;persist()};$('countLabel').textContent=$('count').value;
function toggleCustom(){$('customLength').hidden=$('length').value!=='custom'}$('length').addEventListener('change',toggleCustom);toggleCustom();
function captionCard(text,onChange,allowSave){const div=document.createElement('div');div.className='caption';const content=document.createElement('div');content.textContent=text;div.append(content);const actions=document.createElement('div');actions.className='actions';const btn=(label,fn)=>{const b=document.createElement('button');b.textContent=label;b.onclick=fn;actions.append(b)};btn('Edit',()=>{const input=document.createElement('textarea');input.value=content.textContent;content.replaceWith(input);actions.replaceChildren();btn('Apply',()=>{onChange(input.value);content.textContent=input.value;input.replaceWith(content);actions.replaceChildren();addActions()})});function addActions(){btn('Copy',()=>{if(window.CaptionAndroid){window.CaptionAndroid.copyText(content.textContent)}else if(navigator.clipboard){navigator.clipboard.writeText(content.textContent).catch(()=>alert('Clipboard unavailable'))}});if(allowSave)btn('Save',()=>{saved.unshift({text:content.textContent,id:Date.now()+Math.random()});saveList()});else btn('Delete',()=>{saved=saved.filter(x=>String(x.id)!==div.dataset.id);saveList()})}addActions();div.append(actions);return div}
function saveList(){localStorage.setItem('cc-saved',JSON.stringify(saved));renderSaved()}
function renderSaved(){$('saved').replaceChildren();saved.forEach(item=>{const card=captionCard(item.text,t=>{item.text=t;saveList()},false);card.dataset.id=item.id;$('saved').append(card)})}renderSaved();
function prompt(){
  const character=gender=>{
    const names=Object.keys(categories).concat(gender==='Female'?['Influence & Vulnerability']:[]);
    return gender+' character: relationship '+(state['relationship'+gender]||'Single')+'; personality '+names.flatMap(n=>state[gender+n]||[]).join(', ')
  };
  const length=state.length==='custom'?(state.customLength||'short'):((state.length||'2-3')+' sentences');
  return 'Write one concise fictional caption based on the idea and character settings. Return only the caption.\n'+
    'Idea: '+(state.idea||'')+'\n'+character('Female')+'\n'+character('Male')+'\n'+
    'Male character goal: '+(state.goal||baseGoals[0])+'\n'+
    'Writing style: '+((state.styles||[]).join(', ')||'Storytelling')+'\n'+
    'Length: '+length;
}
let busy=false, modelReady=false;
const setStatus=text=>{$('status').textContent=text};
const setBusy=value=>{busy=value;$('generate').disabled=value;$('regenerate').disabled=value;$('chooseModel').disabled=value};
function generate(){
  if(busy)return;
  if(!window.CaptionAndroid){setStatus('The local GGUF engine is available in the Android APK, not in a browser.');return}
  if(!modelReady){setStatus('Choose a GGUF model first.');return}
  if(!(state.idea||'').trim()){setStatus('Enter a caption idea first.');return}
  window.CaptionAndroid.generate(prompt(),Number(state.count||3));
}
window.CaptionNative={
  onModelStatus(payload){
    let data;try{data=JSON.parse(payload)}catch{data={message:payload,ready:false}}
    modelReady=Boolean(data.ready);
    setStatus(data.message||'');
    $('modelStatus').textContent=data.message||'';
  },
  onStart(){setBusy(true);generated=[];$('results').replaceChildren();setStatus('Generating captions…')},
  onCaption(text){const item={text};generated.push(item);$('results').append(captionCard(text,t=>item.text=t,true));$('results').lastElementChild.scrollIntoView({block:'nearest',behavior:'smooth'})},
  onFinished(text){setBusy(false);setStatus(text)}
};
$('chooseModel').onclick=()=>{if(window.CaptionAndroid){setStatus('Opening model picker…');window.CaptionAndroid.chooseModel()}else setStatus('Model import works in the Android APK.')};
$('generate').onclick=generate;
$('regenerate').onclick=generate;
setStatus('Choose a GGUF model to begin.');
